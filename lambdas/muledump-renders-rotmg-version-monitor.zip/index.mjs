import https from 'https';
import xml2js from 'xml2js';
import zlib from 'zlib';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import fs from "fs";
const config = JSON.parse(fs.readFileSync("./config.json").toString())
const pattern = /\d\.\d\.\d\.\d\.\d(?=\x00)/g;
const s3 = new S3Client(config.aws);

export const handler = async(event) => {

    //  find buildhash
    console.log("Find buildhash")
    let builddata = await new Promise(function (resolve, reject) {
        https.get(config.buildurl, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                resolve(data)
            });

        }).on("error", (err) => {
            console.log("Error: " + err.message);
            reject(err)
        });
    });

    const xmlparser = new xml2js.Parser({explititArray: false});
    builddata = await xmlparser.parseStringPromise(builddata)
    const buildhash = builddata.AppSettings.BuildHash[0]

    //  check if new version
    console.log("Check if new build")
    const buildinfoobject = await new Promise(function (resolve, reject) {
        https.get(config.buildinfourl, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                resolve(JSON.parse(data))
            });

        }).on("error", (err) => {
            console.log("Error: " + err.message);
            reject(err)
        });
    });

    if ( buildinfoobject && buildhash === buildinfoobject.buildhash ) {

        console.log("No update found")
        buildinfoobject.timestamp = new Date()
        if ( !buildinfoobject.published ) buildinfoobject.published = new Date()
        await s3.send(new PutObjectCommand({
            Bucket: config.s3_bucket,
            Key: config.s3_key,
            ContentType: "application/json",
            Body: JSON.stringify(buildinfoobject, null, 4)
        }));

        return {
            statusCode: 200,
            body: "no update found",
        };

    }

    //  find version
    console.log("Find game version")
    const metadataurl = "https://rotmg-build.decagames.com/build-release/" + buildhash + "/rotmg-exalt-win-64/RotMG Exalt_Data/il2cpp_data/Metadata/global-metadata.dat.gz"
    let options = {
        "hostname": "rotmg-build.decagames.com",
        "path": "/build-release/" + buildhash + "/rotmg-exalt-win-64/RotMG%20Exalt_Data/il2cpp_data/Metadata/global-metadata.dat.gz",
        "headers": {
            "Accept-Encoding": "gzip"
        }
    }
    let version = await new Promise(function (resolve, reject) {
        https.get(options, (res) => {

            console.log("Begin streaming")
            const stream = res.headers['content-type'] === 'application/x-gzip' ?
                res.pipe(zlib.createGunzip()) :
                res;

            stream.setEncoding('binary')

            let buffer = ''
            let versions = {};
            stream.on('data', (chunk) => {
                buffer += chunk.toString('binary');
                const matches = buffer.match(pattern);
                if (matches) {
                    for (const match of matches) {
                        if ( !versions[match] ) versions[match] = 0
                        versions[match]++;
                    }
                }
                // we need to keep a few bytes at each chunk boundary,
                // in case the version number is split between two chunks.
                // we don't need to keep anything earlier in the chunk, or
                // from previous chunks, because those have already been
                // searched. the version number pattern is at most 20 bytes,
                // but we'll keep a few more in case it grows in the future.
                buffer = buffer.slice(-100);
            });

            stream.on('end', () => {
                if ( Object.keys(versions).length === 1 ) {
                    resolve(Object.keys(versions)[0])
                } else {
                    resolve("0.0.0.0.0");
                }
            });

        }).on("error", (err) => {
            console.log("Error: " + err.message);
            reject(err)
        });
    });

    let buildinfo = {
        "version": version,
        "buildhash": buildhash,
        "compiledhash": null,
        "timestamp": new Date(),
        "published": new Date()
    }

    console.log(buildinfo)

    await s3.send(new PutObjectCommand({
        Bucket: config.s3_bucket,
        Key: config.s3_key,
        ContentType: "application/json",
        Body: JSON.stringify(buildinfo, null, 4)
    }));

    return {
        statusCode: 200,
        body: "ok",
    };
};
